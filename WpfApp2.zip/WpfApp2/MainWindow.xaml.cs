﻿using Microsoft.Win32;
using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp2
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        List<Class1> feladatok = new List<Class1>();
        public MainWindow()
        {
            InitializeComponent();
        }


        private void btnFajlkivasztas_Click(object sender, RoutedEventArgs e)
        {
            var fajl = new OpenFileDialog();
            if (fajl.ShowDialog() == true)
            {
                StreamReader streamReader = new StreamReader(fajl.FileName);
                while (!streamReader.EndOfStream)
                {
                    string sor = streamReader.ReadLine();
                    string[] mezok = sor.Split(" ");
                    Class1 kifejezes = new Class1(Convert.ToInt32(mezok[0]), Convert.ToInt32(mezok[2]), mezok[1]);
                    feladatok.Add(kifejezes);
                }
                streamReader.Close();
            }

            lblMasodik.Content = $"2. feladat: Kifejezések száma: {feladatok.Count}";
            int mod = feladatok.Count(x => x.Operátor == "mod");
            lblHarmadik.Content = $"3. feladat: Kifejezések maradékos osztással: {mod}";

            lblNegyedik.Content = $"4. feladat: {(feladatok.Any(x => x.Operandus1 % 10 == 0 && x.Operandus2 % 10 == 0) ? "Van ilyen kifejezés!" : "Nincs ilyen kifejezés! :(")}";
            


            lbEredmeny.Items.Add("5. feladat: Statisztika:");
            lbEredmeny.Items.Add($" mod -> {mod} db");
            lbEredmeny.Items.Add($" / -> {feladatok.Count(x => x.Operátor == "/")} db");
            lbEredmeny.Items.Add($" div -> {feladatok.Count(x => x.Operátor == "div")} db");
            lbEredmeny.Items.Add($" - -> {feladatok.Count(x => x.Operátor == "-")} db");
            lbEredmeny.Items.Add($" * -> {feladatok.Count(x => x.Operátor == "*")} db");
            lbEredmeny.Items.Add($" + -> {feladatok.Count(x => x.Operátor == "+")} db");






        }
    }
}
