﻿using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfApp2
{
    internal class Class1
    {
        int operandus1, operandus2;
        string operátor;

        public Class1(int op1, int op2, string operátor) { 
            operandus1 = op1;
            operandus2 = op2;
            this.operátor = operátor;
        
        }

        public int Operandus1 { get => operandus1; }
        public int Operandus2 { get => operandus2; }
        public string Operátor { get => operátor; }

        public void FajlBeolvasas(string fajlnev) { 
        
            foreach (var sor in File.ReadAllLines("kifejezesek.txt"))
            {
                int a = int.Parse(sor.Split()[0]);
                int b = int.Parse(sor.Split()[2]);
                string o = sor.Split()[1];
            }
        }
    }

}
